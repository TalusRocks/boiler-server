const model = require('../models/post-model')

class postController {

  static getAllPosts(req, res, next) {
    const data = model.getAllPosts()
    res.status(200).json({data})
  }

  static getOnePost(req, res, next) {
    const data = model.getOnePost(req.params.id)
    res.status(200).json({data})
  }

  static createNewPost(req, res, next) {
    const data = model.createNewPost(req.body)
    res.status(201).json({data})
  }

  static editPost(req, res, next) {
    const data = model.editPost(req.params.id, req.body)
    res.status(200).json({data})
  }

  static deletePost(req, res, next) {
    const data = model.deletePost(req.params.id)
    res.status(200).json({data})
  }

}

module.exports = postController
