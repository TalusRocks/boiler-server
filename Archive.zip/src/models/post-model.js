//temp data 
const posts = [
  {
    "id": 1,
    "name": "title of post"
  },
  {
    "id": 2,
    "name": "dif title of post"
  },
  {
    "id": 3,
    "name": "third title of post"
  }
]

class postModel {

  static getAllPosts() {
    return posts
  }

  static getOnePost(id) {
    return posts.filter(el => el.id == id)
  }

  static createNewPost(newPost) {
    newPost.id = posts.length + 1
    posts.push(newPost)
    return posts
  }

  static editPost(id, postEdit) {
    let postToEdit = posts.filter(el => el.id == id)
    postToEdit.name = postEdit
    return postToEdit
  }

  static deletePost(id) {
    for (let i = 0; i < posts.length; i++) {
      if (posts[i].id == id) {
        posts.splice(i, 1)
      }
    }
    return posts
  }

}

module.exports = postModel
