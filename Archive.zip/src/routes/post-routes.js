const express = require('express')
const router = express.Router()
const postController = require('../controllers/post-controller')

router.get('/', postController.getAllPosts)
router.get('/:id', postController.getOnePost)
router.post('/', postController.createNewPost)
router.put('/:id', postController.editPost)
router.delete('/:id', postController.deletePost)

module.exports = router
